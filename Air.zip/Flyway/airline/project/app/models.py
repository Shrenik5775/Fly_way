from time import timezone
from django.db import models

# Create your models here.
class AdminMaster(models.Model):
	ad_id = models.AutoField(primary_key=True, unique = True)
	ad_name = models.CharField(max_length=100)
	ad_mobile = models.CharField(max_length=100)
	ad_email = models.CharField(max_length=100)
	ad_password = models.CharField(max_length=100)
	ad_role = models.CharField(max_length=100)
	ad_status = models.IntegerField(default=0)
	ad_created_by = models.CharField(max_length=100, default="")

class FlightDetails(models.Model):
	fl_id = models.AutoField(primary_key=True, unique = True)
	fl_name = models.CharField(max_length=100)
	fl_source = models.CharField(max_length=100)
	fl_destination = models.CharField(max_length=100)
	fl_hours = models.CharField(max_length=100)
	fl_date = models.CharField(max_length=100)
	fl_image = models.ImageField(upload_to="app/static/web/media/images",default="")
	fl_price =  models.CharField(max_length=100,default="")
	fl_status = models.IntegerField(default=0)
	fl_created_by = models.CharField(max_length=100, default="")

class Places(models.Model):
	pl_id = models.AutoField(primary_key=True, unique = True)
	pl_image = models.ImageField(upload_to="app/static/web/media/images",default="")
	pl_name = models.CharField(max_length=100)
	pl_status = models.IntegerField(default=0)
	pl_created_by = models.CharField(max_length=100, default="")

class Category(models.Model):
	ca_id = models.AutoField(primary_key=True, unique = True)
	ca_name = models.CharField(max_length=100)
	ca_status = models.IntegerField(default=0)
	ca_created_by = models.CharField(max_length=100, default="")

class Pilot(models.Model):
	pi_id = models.AutoField(primary_key=True, unique = True)
	pi_flight_name = models.CharField(max_length=100)
	pi_pilot_name = models.CharField(max_length=100)
	pi_pilot_id = models.CharField(max_length=100)
	pi_source = models.CharField(max_length=100)
	pi_destination = models.CharField(max_length=100)
	pi_time = models.CharField(max_length=100)
	pi_joining_date = models.CharField(max_length=100)
	pi_password = models.CharField(max_length=100,default="")
	pi_email = models.CharField(max_length=100,default="")
	pi_status = models.IntegerField(default=0)
	pi_created_by = models.CharField(max_length=100, default="")

class Food(models.Model):
	food_id = models.AutoField(primary_key=True, unique = True)
	food_flight_name = models.CharField(max_length=100)
	food_menu = models.CharField(max_length=100)
	food_details = models.CharField(max_length=100)
	food_status = models.IntegerField(default=0)
	food_created_by = models.CharField(max_length=100, default="")

class Register(models.Model):
	re_id = models.AutoField(primary_key=True, unique = True)
	re_name = models.CharField(max_length=100)
	re_email = models.CharField(max_length=100)
	re_mobile = models.CharField(max_length=100)
	re_password = models.CharField(max_length=100)
	re_address = models.CharField(max_length=100, default="")
	re_secret_key = models.CharField(max_length=100, default="")
	re_status = models.IntegerField(default=0)
	re_created_by = models.CharField(max_length=100)

class Book(models.Model):
	bo_id = models.AutoField(primary_key=True, unique = True)
	bo_first_name = models.CharField(max_length=100)
	bo_last_name = models.CharField(max_length=100)
	bo_dob = models.CharField(max_length=100)
	bo_gender = models.CharField(max_length=100)
	bo_name = models.CharField(max_length=100,default="")
	bo_source = models.CharField(max_length=100,default="")
	bo_destination = models.CharField(max_length=100,default="")
	bo_hours = models.CharField(max_length=100,default="")
	bo_date = models.CharField(max_length=100,default="")
	bo_price = models.CharField(max_length=100,default="")
	bo_reason = models.CharField(max_length=100,default="")
	bo_cancel_status = models.CharField(max_length=100, default="Booked")
	bo_status = models.IntegerField(default=0)
	bo_created_by = models.CharField(max_length=100)
	bo_created_date = models.DateTimeField(auto_now=True)


class Schedule(models.Model):
	sc_id = models.AutoField(primary_key=True, unique = True)
	sc_flight_name = models.CharField(max_length=100)
	sc_pilot_name = models.CharField(max_length=100)
	sc_date = models.CharField(max_length=100)
	sc_source = models.CharField(max_length=100)
	sc_destination = models.CharField(max_length=100)
	sc_time = models.CharField(max_length=100)
	sc_status = models.IntegerField(default=0)
	sc_created_by = models.CharField(max_length=100, default="")

class Contact(models.Model):
	ct_id = models.AutoField(primary_key=True, unique = True)
	ct_name = models.CharField(max_length=100)
	ct_email = models.CharField(max_length=100)
	ct_subject = models.CharField(max_length=100)
	ct_message = models.CharField(max_length=100)
	ct_status = models.IntegerField(default=0)
	ct_created_by = models.CharField(max_length=100, default="")