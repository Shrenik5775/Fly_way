function validateEmail(paramEmailID) {
  var filter = /^[0-9a-z.]+\@[a-z0-9]+\.[a-zA-z0-9]{2,4}$/;

  if (filter.test(paramEmailID)) {
      return true;
  } else {
      return false;
  }
}
function alphaOnly(event) {
var key = event.which ? event.which : event.keyCode;
return (
  (key >= 65 && key <= 90) ||
  key == 8 ||
  (event.charCode >= 97 && event.charCode <= 122) ||
  event.charCode == 32
);
}
function isNumberKey(evt) {
var charCode = (evt.which) ? evt.which : event.keyCode;
if (charCode > 31 && (charCode < 48 || charCode > 57)) {
    return false;
}
return true;
}
$(document).ready(function () {
    $("#btn_add").click(function () {
        // alert($("#source").text());
        if ($("#firstName").val() == "") {
            alert("Please Enter First Name");
            $("#firstName").focus();
            return false
        }
        if ($("#lastName").val() == "") {
            alert("Please Enter Last Name");
            $("#lastName").focus();
            return false
        }
        if ($("#dob").val() == "") {
            alert("Please Enter Date Of Birth");
            $("#dob").focus();
            return false
        }

        if ($("#gender").val() == "") {
            alert("Please Enter Gender");
            $("#gender").focus();
            return false
        }



        
        var formData = new FormData();

       
  

        formData.append("firstName", $("#firstName").val());
        formData.append("lastName", $("#lastName").val());
        formData.append("dob", $("#dob").val());
        formData.append("gender", $("#gender").val());
        formData.append("name", $("#name").text());
        formData.append("source", $("#source").text());
        formData.append("destination", $("#destination").text());
        formData.append("hours", $("#hours").text());
        formData.append("date", $("#date").text());
        formData.append("price", $("#price").text());
        formData.append("csrfmiddlewaretoken", $('input[name=csrfmiddlewaretoken]').val());
        formData.append("action", "add");
      
        // var table = $("#dataTables-example").DataTable();
      
        $.ajax({
          beforeSend: function () {
            $(".btn .spinner-border").show();
            $("#btn_add").attr("disabled", true);
          },
          url: "/book_form/",
          type: "POST",
          // headers: {'X-CSRFToken': '{{ csrf_token }}'},
          data: formData,
          processData: false,
          contentType: false,
          success: function (result) {
           
      
            alert("Booked Successfully");
            payment($("#price").text());
      
          },
          error: function (request, error) {
            console.error(error);
          },
          complete: function () {
            $(".btn .spinner-border").hide();
            $("#btn_add").attr("disabled", false);
          },
        });
      });
});

function payment(amount) {

    var totalAmount = amount;
    // alert(totalAmount);
    var options = {
    "key": "rzp_test_aKbqVbQ3Ciq9KZ",
    // rzp_live_fAt71isKlJSzhX
    "amount": (totalAmount*100), // 2000 paise = INR 20
    "name": "Airline Reservation",
    "description": "Payment",
    "handler": function (response) {
         window.location.href = '/pay_success/';

    },
    "prefill": {
        "contact": $("#txtNumberBook").val(),
        "email":   $("#txtEmailBook").val(),
    },
     
    "theme": {
        "color": "#4caf50"
    }
  };
  var rzp1 = new Razorpay(options);
  rzp1.open();

}
  
