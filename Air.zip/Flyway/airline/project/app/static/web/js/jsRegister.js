function validateEmail(paramEmailID) {
  var filter = /^[0-9a-z.]+\@[a-z0-9]+\.[a-zA-z0-9]{2,4}$/;

  if (filter.test(paramEmailID)) {
      return true;
  } else {
      return false;
  }
}
function alphaOnly(event) {
var key = event.which ? event.which : event.keyCode;
return (
  (key >= 65 && key <= 90) ||
  key == 8 ||
  (event.charCode >= 97 && event.charCode <= 122) ||
  event.charCode == 32
);
}
function isNumberKey(evt) {
var charCode = (evt.which) ? evt.which : event.keyCode;
if (charCode > 31 && (charCode < 48 || charCode > 57)) {
    return false;
}
return true;
}
$(document).ready(function () {
    $("#btn_add").click(function () {
        if ($("#txtName").val() == "") {
            alert("Please enter Name");
            $("#txtName").focus();
            return false
        }
        if ($("#txtEmail").val() == "") {
            alert("Please enter Email");
            $("#txtEmail").focus();
            return false
        }
        if(!validateEmail($("#txtEmail").val())) {
          alert("Please Enter valid Email");
          $("#txtEmail").focus();
          return false;
         }
         if ($("#txtNumber").val().trim().length < 10) {
            alert("Please enter Number");
            $("#txtNumber").focus();
            return false
        }

        if ($("#txtPassword").val() == "") {
            alert("Please enter Number");
            $("#txtPassword").focus();
            return false
        }

        if ($("#txtAddress").val() == "") {
            alert("Please enter Address");
            $("#txtAddress").focus();
            return false
        }

        if ($("#txtSecretKey").val() == "") {
            alert("Please enter Secret Key");
            $("#txtSecretKey").focus();
            return false
        }
        var formData = new FormData();
  

        formData.append("txtName", $("#txtName").val());
        formData.append("txtEmail", $("#txtEmail").val());
        formData.append("txtNumber", $("#txtNumber").val());
        formData.append("txtAddress", $("#txtAddress").val());
        formData.append("txtPassword", $("#txtPassword").val());
        formData.append("txtSecretKey", $("#txtSecretKey").val());
        formData.append("csrfmiddlewaretoken", $('input[name=csrfmiddlewaretoken]').val());
        formData.append("action", "add");
      
        // var table = $("#dataTables-example").DataTable();
      
        $.ajax({
          beforeSend: function () {
            $(".btn .spinner-border").show();
            $("#btn_add").attr("disabled", true);
          },
          url: "/register_form/",
          type: "POST",
          // headers: {'X-CSRFToken': '{{ csrf_token }}'},
          data: formData,
          processData: false,
          contentType: false,
          success: function (result) {
            if(result=="10"){
              alert("User Already Registered");
            }else if(result=="20"){
              alert("Mobile Number Already Exists");
            }else{
      
            alert("Registered Successfully");
            location.reload();
            table.ajax.reload();
            $("#add_modal").modal('hide');
            }
      
          },
          
          error: function (request, error) {
            console.error(error);
          },
          complete: function () {
            $(".btn .spinner-border").hide();
            $("#btn_add").attr("disabled", false);
          },
        });
      });
});

