function getPilotData() {
    // alert("Hi");
    var formData = new FormData();
    formData.append("csrfmiddlewaretoken", $('input[name=csrfmiddlewaretoken]').val());
    formData.append("action", "getData");
  
  
    $.ajax({
  
      url: "/pilot_details/",
      type: "POST",
      data: formData,
      processData: false,
      contentType: false,
      success: function (response) {
  
        console.log(response);
        // $("#dataTables-example tr:gt(0)").remove();
        for (var i = 0; i < response.length; i++) {
          var j = i + 1;
          
          $("#tableData").append('<tr><td>' + j + '</td><td style="display: none;">' + response[i].pi_id + '</td><td>' + response[i].pi_flight_name + '</td><td>' + response[i].pi_pilot_name + '</td><td>' + response[i].pi_source + '</td><td>' + response[i].pi_destination + '</td><td>' + response[i].pi_time + '</td><td>' + response[i].pi_joining_date+'</td></tr>');
        }
      },
      error: function (request, error) {
        console.error(error);
      },
      complete: function () {
  
      },
    });
  
  }
  getPilotData();