$(document).ready(function () {
    $("#btn_add").click(function () {
      // alert($("#txtPrice").val());
        if ($("#txtName").val() == "") {
            alert("Please Enter Flight Name");
            $("#txtName").focus();
            return false;
        }

        if ($("#txtSource").val() == "") {
            alert("Please Enter Source");
            $("#txtSource").focus();
            return false;
        }
        if ($("#txtDestination").val() == "") {
            alert("Please Enter your Destination");
            $("#txtDestination").focus();
            return false;

        }
       
        if ($("#txtHours").val() == "") {
            alert("Please Select Time");
            $("#txtHours").focus();
            return false;
        }
        if ($("#txtDate").val() == "") {
            alert("Please Select Date");
            $("#txtDate").focus();
            return false;
        }
        if ($("#selImage").val() == "") {
          alert("Please Upload Image");
          $("#selImage").focus();
          return false;
        }

        var formData = new FormData();
        var lclFile = document.getElementById("selImage");
        lclImage = lclFile.files[0];

        
          formData.append("txtName", $("#txtName").val());
          formData.append("txtSource", $("#txtSource").val());
          formData.append("txtDestination", $("#txtDestination").val());
          formData.append("txtHours", $("#txtHours").val());
          formData.append("txtPrice", $("#txtPrice").val());
          
          formData.append("txtDate", $("#txtDate").val());
          formData.append("txtImage", lclImage);
          formData.append("txtPrice", $("#txtPrice").val());

          formData.append("csrfmiddlewaretoken", $('input[name=csrfmiddlewaretoken]').val());
          formData.append("action", "add");
        
          // var table = $("#dataTables-example").DataTable();
        
          $.ajax({
            beforeSend: function () {
              $(".btn .spinner-border").show();
              $("#btn_add").attr("disabled", true);
            },
            url: "/flight_details/",
            type: "POST",
            // headers: {'X-CSRFToken': '{{ csrf_token }}'},
            data: formData,
            processData: false,
            contentType: false,
            success: function (result) {
        
              alert("Details Added Successfully");
              location.reload();
              table.ajax.reload();
              $("#add_modal").modal('hide');
        
            },
            error: function (request, error) {
              console.error(error);
            },
            complete: function () {
              $(".btn .spinner-border").hide();
              $("#btn_add").attr("disabled", false);
            },
          });
        });
});

$(document).ready(function () {

    //Edit modal submit click
    $(document).on("click", "#btn_update", function () {
      // alert("hi");
  
      if ($("#txtName1").val().trim().length < 1) {
        alert("Please Enter Flight Name");
        $("#txtName1").focus();
        return false;
      }
  
      if ($("#txtSource1").val().trim().length < 1) {
        alert("Please Enter Source");
        $("#txtSource1").focus();
        return false;
      }
  
      if ($("#txtDestination1").val().trim().length < 1) {
        alert("Please Enter Destination");
        $("#txtDestination1").focus();
        return false;
      }
  
      if ($("#txtHours1").val().trim().length < 1) {
        alert("Please Select Time");
        $("#txtHours1").focus();
        return false;
      }

      if ($("#txtDate1").val().trim().length < 1) {
        alert("Please Select Date");
        $("#txtDate1").focus();
        return false;
      }
  
  
      var formData = new FormData()
      formData.append("txtName1", $("#txtName1").val());
      formData.append("txtSource1", $("#txtSource1").val());
      formData.append("txtDestination1", $("#txtDestination1").val());
      formData.append("txtHours1", $("#txtHours1").val());
      formData.append("txtDate1", $("#txtDate1").val());
      formData.append("txtPrice1", $("#txtPrice1").val());

      formData.append("id", $("#edit_id").val());
      formData.append("csrfmiddlewaretoken", $('input[name=csrfmiddlewaretoken]').val());
      formData.append("action", "update");
  
  
      // var table = $("#dataTables-example").DataTable();
  
      $.ajax({
        beforeSend: function () {
          $(".btn .spinner-border").show();
          $("#btn_update").attr("disabled", true);
        },
        url: "/flight_details/",
        type: "POST",
        data: formData,
        processData: false,
        contentType: false,
        success: function (result) {
          alert("Details Updated Succesfully");
          location.reload();
          table.ajax.reload();
          $("#edit_modal").modal('hide');
        },
        error: function (request, error) {
          console.error(error);
        },
        complete: function () {
          $(".btn .spinner-border").hide();
          $("#btn_update").attr("disabled", false);
        },
      });
    });
  
    //Delete work step
    $(document).on("click", "#btn_delete", function () {
  
      var formData = new FormData();
      formData.append("id", $("#delete_id").val());
      formData.append("csrfmiddlewaretoken", $('input[name=csrfmiddlewaretoken]').val());
      formData.append("action", "delete");
  
  
      // var table = $("#dataTables-example").DataTable();
  
      $.ajax({
        beforeSend: function () {
          $(".btn .spinner-border").show();
        },
  
        url: "/flight_details/",
        type: "POST",
        data: formData,
        processData: false,
        contentType: false,
        success: function () {
          alert("Details deleted succesfully");
          location.reload();
          table.ajax.reload();
          $("#delete_modal").modal('hide');
        },
        error: function (request, error) {
          console.error(error);
        },
        complete: function () {
          $(".btn .spinner-border").hide();
          // Reset Form
          //$("#view_field_form")[0].reset();
          $(".close").click();
        },
      });
    });
  
  });
  
  
  function getFlightDetails() {
    // alert("Hi");
    var formData = new FormData();
    formData.append("csrfmiddlewaretoken", $('input[name=csrfmiddlewaretoken]').val());
    formData.append("action", "getData");
  
  
    $.ajax({
  
      url: "/flight_details/",
      type: "POST",
      data: formData,
      processData: false,
      contentType: false,
      success: function (response) {
  
        console.log(response);
        // $("#dataTables-example tr:gt(0)").remove();
        for (var i = 0; i < response.length; i++) {
          var j = i + 1;
          let image = response[i].fl_image.substring(3);

          $("#tableData").append('<tr><td>' + j + '</td><td style="display: none;">' + response[i].fl_id + '</td><td><img src="'+image+'" style="width:100px; height:100px;"></td><td>' + response[i].fl_name + '</td><td>' + response[i].fl_source + '</td><td>' + response[i].fl_destination + '</td><td>' + response[i].fl_hours + '</td><td>' + response[i].fl_date + '</td><td>' + response[i].fl_price+ '</td><td><div class="d-flex" style="justify-content: space-evenly;"><a href="javascript:void(0);" id="edit_row" title="View/Edit" data-bs-toggle="modal" data-bs-target="#edit_modal"  class="text-primary" onClick="getRowsUpdate();">Edit</a><a href="javascript:void(0);" title="Delete" data-bs-toggle="modal" data-bs-target="#delete_modal" class="text-danger" id="delete_row" onClick="getRowsDelete();">Delete</a></div></td></tr>');
        }
      },
      error: function (request, error) {
        console.error(error);
      },
      complete: function () {
  
      },
    });
  
  }
  
  function getRowsUpdate() {
    $("#tableData tr").click(function () {
      var currentRow = $(this).closest("tr");
      var lclID = currentRow.find("td:eq(1)").text();
      var lclName = currentRow.find("td:eq(3)").text();
      var lclSource = currentRow.find("td:eq(4)").text();
      var lclDestination = currentRow.find("td:eq(5)").text();
      var lclTime = currentRow.find("td:eq(6)").text();
      var lclDate = currentRow.find("td:eq(7)").text();
      var lclDate1 = currentRow.find("td:eq(8)").text();

      // alert(lclID);  
      $("#txtName1").val(lclName);
      $("#txtSource1").val(lclSource);
      $("#txtDestination1").val(lclDestination);
      $("#txtHours1").val(lclTime);
      $("#txtDate1").val(lclDate);
      $("#txtPrice1").val(lclDate1);

      $("#edit_id").val(lclID);
  
    });
  }
  
  
  function getRowsDelete() {
    $("#tableData tr").click(function () {
      var currentRow = $(this).closest("tr");
      var lclID = currentRow.find("td:eq(1)").text();
      // alert(lclID);
      $("#delete_id").val(lclID);
  
    });
  }
  
  getFlightDetails()
  