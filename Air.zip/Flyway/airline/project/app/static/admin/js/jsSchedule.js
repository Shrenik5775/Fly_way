
$("#btn_add").click(function () {
  // alert($("#selPilot").val());
    if ($("#selPilot").val() == "") {
        alert("Please Select Pilot Name");
        $("#selPilot").focus();
        return false;
    }
    if ($("#selFlight").val() == "") {
        alert("Please Enter Flight Name");
        $("#selFlight").focus();
        return false;
    }
    if ($("#txtDate").val() == "") {
        alert("Please Enter Date");
        $("#txtDate").focus();
        return false;
    }

    if ($("#txtSource").val() == "") {
        alert("Please Enter source");
        $("#txtSource").focus();
        return false;
    }
    if ($("#txtDestination").val() == "") {
        alert("Please Enter Destination");
        $("#txtDestination").focus();
        return false;

    }

    if ($("#txtTime").val() == "") {
        alert("Please Select Time");
        $("#txtTime").focus();
        return false;
    }

    var formData = new FormData();
    //   var lclFile = document.getElementById("selImage");
    //   lclImage = lclFile.files[0];

    formData.append("selPilot", $("#selPilot").val());
    formData.append("selFlight", $("#selFlight").val());
    formData.append("txtDate", $("#txtDate").val());
    formData.append("txtSource", $("#txtSource").val());
    formData.append("txtDestination", $("#txtDestination").val());
    formData.append("txtTime", $("#txtTime").val());


    formData.append("csrfmiddlewaretoken", $('input[name=csrfmiddlewaretoken]').val());
    formData.append("action", "add");

    // var table = $("#dataTables-example").DataTable();

    $.ajax({
        beforeSend: function () {
            $(".btn .spinner-border").show();
            $("#btn_add").attr("disabled", true);
        },
        url: "/schedule_details/",
        type: "POST",
        // headers: {'X-CSRFToken': '{{ csrf_token }}'},
        data: formData,
        processData: false,
        contentType: false,
        success: function (result) {

            alert("Details Added Successfully");
            location.reload();
            table.ajax.reload();
            $("#add_modal").modal('hide');

        },
        error: function (request, error) {
            console.error(error);
        },
        complete: function () {
            $(".btn .spinner-border").hide();
            $("#btn_add").attr("disabled", false);
        },
    });
});
$(document).ready(function () {

    //Edit modal submit click
    $(document).on("click", "#btn_update", function () {
      // alert("hi");
    if ($("#selPilot1").val() == "") {
        alert("Please Select Pilot Name");
        $("#selPilot1").focus();
        return false;
    }
    if ($("#selFlight1").val() == "") {
        alert("Please Enter Flight Name");
        $("#selFlight1").focus();
        return false;
    }
    if ($("#txtDate1").val() == "") {
        alert("Please Enter Date");
        $("#txtDate1").focus();
        return false;
    }

    if ($("#txtSource1").val() == "") {
        alert("Please Enter source");
        $("#txtSource1").focus();
        return false;
    }
    if ($("#txtDestination1").val() == "") {
        alert("Please Enter Destination");
        $("#txtDestination1").focus();
        return false;

    }

    if ($("#txtTime1").val() == "") {
        alert("Please Select Time");
        $("#txtTime1").focus();
        return false;
    }

    var formData = new FormData();
    //   var lclFile = document.getElementById("selImage");
    //   lclImage = lclFile.files[0];

    formData.append("selPilot1", $("#selPilot1").val());
    formData.append("selFlight1", $("#selFlight1").val());
    formData.append("txtDate1", $("#txtDate1").val());
    formData.append("txtSource1", $("#txtSource1").val());
    formData.append("txtDestination1", $("#txtDestination1").val());
    formData.append("txtTime1", $("#txtTime1").val());
      formData.append("id", $("#edit_id").val());
      formData.append("csrfmiddlewaretoken", $('input[name=csrfmiddlewaretoken]').val());
      formData.append("action", "update");
  
  
      // var table = $("#dataTables-example").DataTable();
  
      $.ajax({
        beforeSend: function () {
          $(".btn .spinner-border").show();
          $("#btn_update").attr("disabled", true);
        },
        url: "/schedule_details/",
        type: "POST",
        data: formData,
        processData: false,
        contentType: false,
        success: function (result) {
          alert("Details Updated Succesfully");
          location.reload();
          table.ajax.reload();
          $("#edit_modal").modal('hide');
        },
        error: function (request, error) {
          console.error(error);
        },
        complete: function () {
          $(".btn .spinner-border").hide();
          $("#btn_update").attr("disabled", false);
        },
      });
    });
  
    //Delete work step
    $(document).on("click", "#btn_delete", function () {
  
      var formData = new FormData();
      formData.append("id", $("#delete_id").val());
      formData.append("csrfmiddlewaretoken", $('input[name=csrfmiddlewaretoken]').val());
      formData.append("action", "delete");
  
  
      // var table = $("#dataTables-example").DataTable();
  
      $.ajax({
        beforeSend: function () {
          $(".btn .spinner-border").show();
        },
  
        url: "/schedule_details/",
        type: "POST",
        data: formData,
        processData: false,
        contentType: false,
        success: function () {
          alert("Details deleted succesfully");
          location.reload();
          table.ajax.reload();
          $("#delete_modal").modal('hide');
        },
        error: function (request, error) {
          console.error(error);
        },
        complete: function () {
          $(".btn .spinner-border").hide();
          // Reset Form
          //$("#view_field_form")[0].reset();
          $(".close").click();
        },
      });
    });
  
  });
  

  

  function getAdminMasterData() {
    // alert("Hi");
    var formData = new FormData();
    formData.append("csrfmiddlewaretoken", $('input[name=csrfmiddlewaretoken]').val());
    formData.append("action", "getData");
  
  
    $.ajax({
  
      url: "/pilot_details/",
      type: "POST",
      data: formData,
      processData: false,
      contentType: false,
      success: function (response) {
  
        console.log(response);
        // $("#dataTables-example tr:gt(0)").remove();
        for (var i = 0; i < response.length; i++) {
          var j = i + 1;
          
          $("#selPilot").append('<option value="'+response[i].pi_pilot_name+'">'+response[i].pi_pilot_name+'</option>');
          $("#selPilot1").append('<option value="'+response[i].pi_pilot_name+'">'+response[i].pi_pilot_name+'</option>');

        }
      },
      error: function (request, error) {
        console.error(error);
      },
      complete: function () {
  
      },
    });
  
  }
  getAdminMasterData();


function getFlightDetails() {
    // alert("Hi");
    var formData = new FormData();
    formData.append("csrfmiddlewaretoken", $('input[name=csrfmiddlewaretoken]').val());
    formData.append("action", "getData");
  
  
    $.ajax({
  
      url: "/flight_details/",
      type: "POST",
      data: formData,
      processData: false,
      contentType: false,
      success: function (response) {
  
        console.log(response);
        // $("#dataTables-example tr:gt(0)").remove();
        for (var i = 0; i < response.length; i++) {
          var j = i + 1;
          // let image = response[i].fl_image.substring(3);
          $("#selFlight").append('<option value="'+response[i].fl_name+'">'+response[i].fl_name+'</option>');
          $("#selFlight1").append('<option value="'+response[i].fl_name+'">'+response[i].fl_name+'</option>');



        }
      },
      error: function (request, error) {
        console.error(error);
      },
      complete: function () {
  
      },
    });
  
  }

  getFlightDetails();


    function getScheduleData() {
    // alert("Hi");
    var formData = new FormData();
    formData.append("csrfmiddlewaretoken", $('input[name=csrfmiddlewaretoken]').val());
    formData.append("action", "getData");
  
  
    $.ajax({
  
      url: "/schedule_details/",
      type: "POST",
      data: formData,
      processData: false,
      contentType: false,
      success: function (response) {
  
        console.log(response);
        // $("#dataTables-example tr:gt(0)").remove();
        for (var i = 0; i < response.length; i++) {
          var j = i + 1;
          
          $("#tableData").append('<tr><td>' + j + '</td><td style="display: none;">' + response[i].sc_id + '</td><td>' + response[i].sc_pilot_name + '</td><td>' + response[i].sc_flight_name + '</td><td>' + response[i].sc_date + '</td><td>' + response[i].sc_source + '</td><td>' + response[i].sc_destination + '</td><td>' + response[i].sc_time + '</td><td><div class="d-flex" style="justify-content: space-evenly;"><a href="javascript:void(0);" id="edit_row" title="View/Edit" data-bs-toggle="modal" data-bs-target="#edit_modal"  class="text-primary" onClick="getRowsUpdate();">Edit</a><a href="javascript:void(0);" title="Delete" data-bs-toggle="modal" data-bs-target="#delete_modal" class="text-danger" id="delete_row" onClick="getRowsDelete();">Delete</a></div></td></tr>');
        }
      },
      error: function (request, error) {
        console.error(error);
      },
      complete: function () {
  
      },
    });
  
  }
  
getScheduleData();

  function getRowsUpdate() {
    $("#tableData tr").click(function () {
      var currentRow = $(this).closest("tr");
      var lclID = currentRow.find("td:eq(1)").text();
      var lclName = currentRow.find("td:eq(2)").text();
      var lclPilotName = currentRow.find("td:eq(3)").text();
      var lclPilotID = currentRow.find("td:eq(4)").text();
      var lclSource = currentRow.find("td:eq(5)").text();
      var lclDestination = currentRow.find("td:eq(6)").text();
      var lclTime = currentRow.find("td:eq(7)").text();
      var lclDate = currentRow.find("td:eq(8)").text();
      // alert(lclPilotName);  
      $("#selPilot1").val(lclName);
      $("#selFlight1").val(lclPilotName);
      $("#txtDate1").val(lclPilotID);
      $("#txtSource1").val(lclSource);
      $("#txtDestination1").val(lclDestination);
      $("#txtTime1").val(lclTime);
      $("#edit_id").val(lclID);
  
    });
  }
  
  
  function getRowsDelete() {
    $("#tableData tr").click(function () {
      var currentRow = $(this).closest("tr");
      var lclID = currentRow.find("td:eq(1)").text();
      // alert(lclID);
      $("#delete_id").val(lclID);
  
    });
  }

  