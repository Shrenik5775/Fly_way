function getData() {
	// alert("Hi");
	var formData = new FormData();
	formData.append("csrfmiddlewaretoken", $('input[name=csrfmiddlewaretoken]').val());
	formData.append("action", "getData");


	$.ajax({

		url: "/get_queries/",
		type: "POST",
		data: formData,
		processData: false,
		contentType: false,
		success: function (response) {

			// console.log(response);
			for (var i = 0; i < response.length; i++) {
				var j = i + 1;
				// let image = response[i].ho_image.substring(3);

				$("#tableData").append('<tr><td>' + j + '</td><td style="display: none;">' + response[i].ct_id + '</td><td>' + response[i].ct_name + '</td><td>'  + response[i].ct_email + '</td><td>'  + response[i].ct_subject + '</td><td>'  + response[i].ct_message + '</td></tr>');
			}
		},
		error: function (request, error) {
			console.error(error);
		},
		complete: function () {

		},
	});
}

getData();