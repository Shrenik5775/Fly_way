function getUserDetails() {
    // alert("Hi");
    var formData = new FormData();
    formData.append("csrfmiddlewaretoken", $('input[name=csrfmiddlewaretoken]').val());
    formData.append("action", "getData");
  
  
    $.ajax({
  
      url: "/user_details/",
      type: "POST",
      data: formData,
      processData: false,
      contentType: false,
      success: function (response) {
  

       
        // $("#dataTables-example tr:gt(0)").remove();
        for (var i = 0; i < response.length; i++) {
            var j = i + 1;

          $("#tableData").append('<tr><td>' + j + '</td><td style="display: none;">' + response[i].re_id + '</td><td>' + response[i].re_name + '</td><td>' + response[i].re_email + '</td><td>' + response[i].re_mobile + '</td></tr>');
        }
      },
      error: function (request, error) {
        console.error(error);
      },
      complete: function () {
  
      },
    });
  
  }

  getUserDetails();