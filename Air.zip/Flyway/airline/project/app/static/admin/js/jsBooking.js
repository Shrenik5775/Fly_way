function getAdminMasterData() {
    // alert("Hi");
    var formData = new FormData();
    formData.append("csrfmiddlewaretoken", $('input[name=csrfmiddlewaretoken]').val());
    formData.append("action", "getData");
  
  
    $.ajax({
  
      url: "/booking_details/",
      type: "POST",
      data: formData,
      processData: false,
      contentType: false,
      success: function (response) {
  
        console.log(response);
        // $("#dataTables-example tr:gt(0)").remove();
        for (var i = 0; i < response.length; i++) {
          var j = i + 1;
          
          $("#tableData").append('<tr><td>' + j + '</td><td style="display: none;">' + response[i].bo_id + '</td><td>' + response[i].bo_name+ '</td><td>' + response[i].bo_price+ '</td><td>' + response[i].bo_first_name+ '</td><td>' + response[i].bo_last_name + '</td><td>' + response[i].bo_dob + '</td><td>' + response[i].bo_gender + '</td><td>' + response[i].bo_source + '</td><td>' + response[i].bo_destination + '</td><td>' + response[i].bo_hours + '</td><td>' + response[i].bo_date + '</td><td>' + response[i].bo_cancel_status + '</td><td>' + response[i].bo_reason + '</td></tr>');
        }
      },
      error: function (request, error) {
        console.error(error);
      },
      complete: function () {
  
      },
    });
  
  }
  getAdminMasterData();
  